  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
                  <!-- menu profile quick info -->
            <div class="profile">
              <div class="profile_pic">
                <img src="images/img_logo.png" alt="..." class="img-circle profile_img">
              </div>
              
            </div>
            <!-- /menu profile quick info -->
            <div class="clearfix"></div>

      

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
             
              <div class="menu_section">
               
               <ul class="nav side-menu">
				<li><a href="index.php"><i class="fa fa-home"></i> Dashboard </a></li>
                  <li><a href="customers.php"><i class="fa fa-edit"></i> Customers </span></a></li>
                  <li><a><i class="fa fa-desktop"></i> Products <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="product-category.php">Product Category</a></li>
					  <li><a href="addsub_catagory.php">Product Sub Category</a></li>
                      <li><a href="product.php">Products</a></li>
                      
                    </ul>
                  </li>
                  <li><a><i class="fa fa-table"></i> Manage Sale <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
					 <li><a href="pending-orders.php">Pending Orders</a></li>
                      <li><a href="sales.php">Completed Orders</a></li>
                    </ul>
                  </li>
                  <li><a href="payments.php"><i class="fa fa-bar-chart-o"></i> Payments </a></li>
                  <li><a><i class="fa fa-bug"></i> Email <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="newmessage.php">New Message</a></li>
                      <li><a href="messages.php">Messages</a></li>
					</ul>
                  </li>
				  <li><a href="inventory.php"><i class="fa fa-clone"></i> Inventory </a></li>  
                  <li><a><i class="fa fa-windows"></i> Coupon <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="new_coupon.php">Add New Coupon</a></li>
                      <li><a href="view_coupon.php">View Coupon</a></li>                      
                    </ul>
                  </li>
                  <li><a href="settings.php"><i class="fa fa-sitemap"></i> Settings </a></li>                  
                  
                </ul>
              </div>

            </div>
            <!-- /sidebar menu -->


          </div>
        </div>