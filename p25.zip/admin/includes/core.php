<?php

$current_file = $_SERVER['SCRIPT_NAME'];

?>