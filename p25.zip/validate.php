<!-- Modal -->
<div id="myModal" class="modal fade modelheight" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
		
      <div class="modal-header bottomborderno">
		<div class="modal-close">
			<img class="" data-dismiss="modal" src="img/closebtn.jpg" />
		</div>
        <div class="modal-logo">
			<img class="" src="img/smalllogowhite.jpg" />
		</div>
		<h4 class="text-center fontsize24">Enter your email address</h4>
		<p class="text-center fontsize16"><style="color:#cccccc;">no credit card  needed</p>
		</div>
      <div class="modal-body paddingtb100">
		<form>
		    
			<div class="form-group">
				<input type="email" class="form-control inputreg" placeholder=" email" name="email" id="email" />
			</div>
			<div class="alert alert-danger">
			<strong>Wrong!</strong> Username or password.
			</div>
			<div class="form-group">
				<input type="password" class="form-control inputreg" placeholder=" password" name="password" id="pwd" />
			</div>			
			<input type="submit" class="btn regbtn" value="SIGNUP"/>
		</form>
		<div class="modal-bottom">
		
		<a href="#">terms and condtion</a></p>
      </div>
      </div>
	  
    </div>

  </div>
</div>
