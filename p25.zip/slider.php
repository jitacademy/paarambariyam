<div class="row row2" style="margin-top: 14px;">
<div class="col-md-12">
			<div class="carousel slide" id="carousel-693768">
				<ol class="carousel-indicators">
					<li class="active" data-slide-to="0" data-target="#carousel-693768">
					</li>
					<li data-slide-to="1" data-target="#carousel-693768">
					</li>
					<li data-slide-to="2" data-target="#carousel-693768">
					</li>
				</ol>
				<div class="carousel-inner">
					<div class="item active">
						<img alt="Carousel Bootstrap First" src="img/slider1.jpg">
						<div class="carousel-caption">
							<p style="color:#999999">ON ORDERS OVER <img src="img/ic_home_rs_red_16_px.png"><span class="sliderred">200</span></p>
							<h1 class="sliderh1">
								FREE <br>SHIPPING
							</h1>
			
							<p>
								<a class="slidershop" href="#">SHOP NOW!</a>
							</p>
						</div>
					</div>
					<div class="item">
						<img alt="Carousel Bootstrap Second" src="img/slider2.jpg">
						<div class="carousel-caption">
							<p style="color:#999999">ON ORDERS OVER <img src="img/ic_home_rs_red_16_px.png"><span class="sliderred">200</span></p>
							<h1 class="sliderh1">
								FREE <br>SHIPPING
							</h1>
			
							<p>
								<a class="slidershop" href="#">SHOP NOW!</a>
							</p>
						</div>
					</div>
					<div class="item">
						<img alt="Carousel Bootstrap Third" src="img/slider3.jpg">
						<div class="carousel-caption">
							<p style="color:#999999">ON ORDERS OVER <img src="img/ic_home_rs_red_16_px.png"><span class="sliderred">200</span></p>
							<h1 class="sliderh1">
								FREE <br>SHIPPING
							</h1>
			
							<p>
								<a class="slidershop" href="#">SHOP NOW!</a>
							</p>
						</div>
					</div>
				</div> <a class="left carousel-control" href="#carousel-693768" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a> <a class="right carousel-control" href="#carousel-693768" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>
			</div>
		</div>
		</div>