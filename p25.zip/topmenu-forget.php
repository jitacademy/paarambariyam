<div class="row">
<div class="col-md-12">
			<div class="col-md-2">
			<img alt="logo" class="img-responsive" src="img/img_logo.png" style="margin-left: 117px;">
			</div>
			<div class="col-md-10">
			<nav class="navbar navbar-default" role="navigation" style="margin-bottom: 5px;" >
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="margin-left: 50px;">
					<ul class="nav navbar-nav topmenu">
						<li class="dropdown">
							 <a href="#" class="dropdown-toggle topmenulia" data-toggle="dropdown">English  <img src="img/ic_down_arrow_gray.png"></a>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Hindi</a>
								</li>
								<li>
									<a href="#">Tamil</a>
								</li>
								<li>
									<a href="#">Malayalam</a>
								</li>
								
								<li>
									<a href="#">Kannadam</a>
								</li>
							</ul>
						</li>
						<li class="dropdown">
							 <a href="#" class="dropdown-toggle topmenulia" data-toggle="dropdown">INR  <img src="img/ic_down_arrow_gray.png"></a>
							<ul class="dropdown-menu">
								<li>
									<a href="#">USD</a>
								</li>
							</ul>
						</li>
						<li class="active">
							<a href="#" class="topmenulia">My Account</a>
						</li>
						<li class="active">
							<a href="#" class="topmenulia">My Wishlist</a>
						</li>
						<li class="active">
							<a href="#" class="topmenulia">Checkout</a>
						</li>
						<li class="active">
							<a href="#" class="topmenulia" data-toggle="modal" data-target="#myModal">Login</a>
						</li>
							<li>
							<li class="dropdown">
							 <a href="#" class="dropdown-toggle topmenulia1" data-toggle="dropdown">  <img src="img/ic_home_menu_cart.png">  <span style="color:#3aaaa3;font-weight: 600;">Cart</span> 0 Item(s)  <img src="img/ic_down_arrow_gray.png"></a>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">Separated link</a>
								</li>
							</ul>
						</li>
							</li>							
					</ul>
					
					
				</div>
				
			</nav>
			<nav class="navbar navbar-default" role="navigation" style="font-size: 21px; margin-bottom: 5px;">			
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1" style="margin-left: 50px;">
					<ul class="nav navbar-nav" style="margin-top: 30px;margin-left:10px;">
						<li class="dropdown dropdown1">
							 <a href="#" class="dropdown-toggle hovermenua" data-toggle="dropdown">ORGANIC FOOD  <img src="img/ic_down_arrow_green.png"></a>
							<ul class="dropdown-menu dropdown-content1">
								<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-10">
					<div class="row">
						<div class="col-md-12">
						
						<div class="row">
    <div class="col-md-2 col-md-offset-1" style="width: 20.667%;">
	
	<div class="row-fluid">
	
	<p>ORGANIC CEREALS</p>
    <div class="span2 offset1">
	<p>> Organic Cereal Grains</p>
	</div>
    <div class="span2">
	
	<p>> Organic Flours (Atta) and Dalia</p>

	</div>
    <div class="span2"><p>Maize</p></div>
    <div class="span2"><p>Barley</p></div>
    <div class="span2"><p>Mulitigrain</p></div>
	<div class="span2"><p>Wheat</p></div>
	<div class="span2"><p>Bajra</p></div>
	<div class="span2"><p>Ragi</p></div>
	<div class="span2">> Organic Rice</div>
	<p>ORGANIC SPICES</p>
	<div class="span2">> Flavouring Spices</div>
	<div class="span2">> Whole Spices</div>
	<div class="span2">> Spices powder</div>
	<p>NUTS,SEEDS & DRY FRUITS</p>
	<div class="span2">> Dry Fruite</div>
	<div class="span2">Organic Nuts</div>
	<div class="span2">Seeds <img src="img/ic_home_popular_new.png" ></div>
</div>
	
	</div>
    <div class="col-md-2">SNACKS
	<div class="span2 offset1"><p>Breakfast Cereals</p></div>
	<div class="span2"><p>Organic Cookies</p></div>
	<div class="span2"><p>Gluten Free  Cookies</p></div>
	<div class="span2"><p>Crunchy Snacks</p></div>
	<div class="span2"><p>Organic Biscuits</p></div>
	<div class="span2"><p>Freeze Dried Fruits</p></div>
	<div class="span2"><p>Puffed Snacks</p></div>
	<div class="span2"><p>Namkeen <img src="img/ic_home_popular_new.png" ></p></div>
	<p>MASALA MIXES</p>
	<div class="span2">Indian Masala<p></p></div>
	<div class="span2"><p> Indian Masala</p></div>
	<p>ORGANIC CONDIMENTS</p>
	<div class="span2"><p>> Chutneys</p></div>
	</div>
    <div class="col-md-2"><p>GLUTEN FREE FOOD</p>
	<div class="span2 offset1"><p>> Creals</p></div>
	<div class="span2"><p>> Spices</p></div>
	<div class="span2"><p>> Pluses and Beans</p></div>
	<div class="span2"><p>> Tea and Coffee</p></div>
	<div class="span2"><p>> Processed Food</p></div>
	<div class="span2"><p>> Snacks</p></div>
	<div class="span2"><p>> Condiments</p></div>
	<div class="span2"><p>> International Food</p></div>
	<div class="span2"><p>> Nuts & Try Fruits</p></div>
	<p>PROCESSED FOOD</p>
	<div class="span2"><p>> Ready to eat</p></div>
	<div class="span2"><p>> Honey</p></div>
	<div class="span2"><p>> Instand Mixes</p></div>
	<div class="span2"><p>> Pickles <img src="img/ic_home_popular_new.png" ></p></div>
	<div class="span2"><p>Oanic Jamsg <img src="img/ic_home_popular_new.png" ></p></div>
	<p>SAUCES & Butters</p>
	<div class="span2"><p>> Sauces <img src="img/ic_home_popular_new.png" ></p></div>
	</div>
	
	
	<div class="col-md-2"><p>INTERNATIONAL FOOD</p>
	<div class="span2 offset1"><p>> Organic Pasta</p></div>
	<div class="span2"><p>> Soup</p></div>
	<div class="span2"><p>> English Aromatic Herbs</p></div>
	<div class="span2"><p>> Seasoning</p></div>
	<div class="span2"><p>> Rubs</p></div>
	<div class="span2"><p>> Snacks <img src="img/ic_home_popular_new.png" ></p></div>
	
	<p>PLUSES AND  BEANS</p>
	<div class="span2"><p>> Organic Beans</p></div>
	<div class="span2"><p>> Organic Dat</p></div>
	
	</div>
	
	
	
	
	<div class="col-md-2">TEA AND COFFEE</div>
	<div class="span2 offset1"><p> Organic Tea</p></div>
	<div class="span2"><p>> Masala Tea</p></div>
	<div class="span2"><p>> Flavored Tea</p></div>
	<div class="span2"><p>> Coffee</p></div>
	<p>OIL & GHEE</p>
	<div class="span2"><p>> Organic Desi Ghee</p></div>
	<div class="span2"><p>> Edible Oils</p></div>
	<p>FRUITS & VEGETABLES</p>
	<div class="span2"><p>> Mango <img src="img/ic_home_popular_new.png" ></p></div>
    
</div>
						
						
						</div>
					</div>
				</div>
				<div class="col-md-2">
				BRANDS
				<p>Aum fresh</p>
				<p>Chamong</p>
				<p>Conscious Food</p>
				<p>Devbhumi <img src="img/ic_home_popular_new.png" ></p>
				<p>Dear Earth Organic</p>
				<p>Down to Earth</p>
				<p>Ecolife Organic <img src="img/ic_home_popular_new.png" ></p>
				<p>Green Sense</p>
				<p>Grenera</p>
				<p>Marson Coffee</p>
				<p>Natureland Organics <img src="img/ic_home_popular_new.png" ></p>
				<p>Nature Organic <img src="img/ic_home_popular_new.png" ></p>
				<p>Nature N Me <img src="img/ic_home_popular_new.png" ></p>
				<p>Naturally Yours <img src="img/ic_home_popular_new.png" ></p>
				<p>Organica</p>
				<p>Organic India</p>
				<p>Organic Wellness <img src="img/ic_home_popular_new.png" ></p>
				<p>Organic Tattva</p>
				<p>Phalada Pure & Sure</p>
				<p>Sattvic</p>
				<p>Sunrice <img src="img/ic_home_popular_new.png" ></p>
				<p>The Organic Kitchen <img src="img/ic_home_popular_new.png" ></p>
				<p>Vedantika Herbals</p>
				<p>Vision Fresh</p>
				<p>Woods and Petals</p>
				<p>Explore more Brands >></p>
				
				</div>
			</div>
		</div>
	</div>
</div>
							</ul>
						</li>
						<li class="dropdown">
							 <a href="#" class="dropdown-toggle headecolor" data-toggle="dropdown">HEALTH & WELLNESS  <img src="img/ic_down_arrow_green.png"></a>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">Separated link</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">One more separated link</a>
								</li>
							</ul>
						</li>
						<li class="dropdown">
							 <a href="#" class="dropdown-toggle headecolor" data-toggle="dropdown">BEAUTY CARE  <img src="img/ic_down_arrow_green.png"></a>
							<ul class="dropdown-menu">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">Separated link</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">One more separated link</a>
								</li>
							</ul>
						</li>
						<li class="dropdown ">
							 <a href="#" class="dropdown-toggle headecolor" data-toggle="dropdown">BABY & KIDS  <img src="img/ic_down_arrow_green.png"></a>
							<ul class="dropdown-menu headecolor">
								<li>
									<a href="#">Action</a>
								</li>
								<li>
									<a href="#">Another action</a>
								</li>
								<li>
									<a href="#">Something else here</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">Separated link</a>
								</li>
								<li class="divider">
								</li>
								<li>
									<a href="#">One more separated link</a>
								</li>
							</ul>
						</li>
						<li>
							<form>
						 
						<button type="submit" class="btn_offer">
							OFFERS
						</button>
					</form>
						</li>
					</ul>
					
					
				</div>
				
			</nav>
		</div>
		</div>
		</div>
<!-- Modal -->
<div id="myModal" class="modal fade modelheight" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
		
      <div class="modal-header bottomborderno">
		<div class="modal-close">
			<img class="" data-dismiss="modal" src="img/closebtn.jpg" />
		</div>
        <div class="modal-logo">
			<img class="" src="img/smalllogowhite.jpg" />
		</div>
		<h4 class="text-center fontsize24">Enter Your Email Address</h4>
		<p class="text-center fontsize16 text-muted">We'll get you back on track</p>
		</div>
      <div class="modal-body paddingtb100">
		<form>
		    
			<div class="form-group">
				<input type="email" class="form-control inputreg" placeholder="E-mail" name="email" id="email" />
			</div>
					
			<input type="submit" class="btn regbtn" value="REQUEST RESET LINK"/>
		</form>
		<div class="modal-bottom">
		
		
      </div>
      </div>
	  
    </div>

  </div>
</div>
